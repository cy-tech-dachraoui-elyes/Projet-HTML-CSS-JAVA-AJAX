
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title> Jeunes 6.4 </title>
        <link rel="stylesheet" type="text/css" href="consultant.css">
    </head>
    
    <body>

    <?php
    session_start();
    if (isset($_SESSION['user'])) {
       echo "Bienvenue" . htmlspecialchars($_SESSION['user']) . "!";
    } else {
        consol.log($_SESSION);
        header("Location: /connexion/connexion.php");
        exit;  
    }
?>

        <div class="bande-grise">
            
            <div class="bande-centree">
                <div class="texte2">
                    <a href="jeune.php" class="aj">
                        <span> <button class="jeune"> JEUNE </button> </span>
                    </a>
                    
                    <a href="referent.php" class="ar">
                        <span class="referent">RÉFÉRENT</span>
                    </a>
                    
                    <a href="consultant.php" class="ac">
                        <span class="consultant">CONSULTANT</span>
                    </a>
                    
                    <a href="partenaire.html" class="ap">
                        <span class="partenaires"> PARTENAIRES</span>
                    </a>
                    
                </div>
            </div>

            <div class="contenu">
                <a href="accueil.php">
                    <img src="/image/jeunes.PNG" alt="Image">
                </a>
                    
                <div class="texte">
                    <p> CONSULTANT </p>
                </div>
                <div class="t2">
                    <p> Je donne de la valeur à ton engagement</p>
                </div>
            </div>
            
        </div>
        
        <p class="dec"> Validez cet engagement en prenant en compte sa valeur </p>
        
        <img src="/image/traitBleu.jpg" alt="traitbleu" class="traitbleu">

        
        
    </body>
</html>


