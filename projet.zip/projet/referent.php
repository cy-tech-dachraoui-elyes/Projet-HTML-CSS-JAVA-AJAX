
<!DOCTYPE html>



<html>

    <head>
        <meta charset="UTF-8">
        <title> Jeunes 6.4 </title>
        <link rel="stylesheet" type="text/css" href="referent.css">
        <script src="maxChoix.js" type="text/javascript"> </script>
    </head>
    
    <body>

<?php
    session_start();
    if (isset($_SESSION['user'])) {
       echo "Bienvenue" . htmlspecialchars($_SESSION['user']) . "!";
    } else {
        consol.log($_SESSION);
        header("Location: /connexion/connexion.php");
        exit;  
    }
?>

        <div class="bande-grise">
            
            <div class="bande-centree">
                <div class="texte2">
                    <a href="Jeune/Jeune.php" class="aj">
                        <span> <button class="jeune"> JEUNE </button> </span>
                    </a>
                    
                    <a href="referent.php" class="ar">
                        <span class="referent">RÉFÉRENT</span>
                    </a>
                    
                    
                    <a href="consultant.php" class="ac">
                        <span class="consultant">CONSULTANT</span>
                    </a>
                    
                    <a href="partenaire.html">
                        <span> <button class="partenaires"> PARTENAIRES </button> </span>
                    </a>
                </div>
            </div>
            
            <div>
<!--                <label for="commentaire">Commentaire:</label>-->
                <textarea id="commentaire" name="commentaire" required class="comm"></textarea><br>
            </div>
            
            <div class="commentaire">
                <p class="comment"> COMMENTAIRES </p>
            </div>
            
            <div class="contenu">
                <a href="accueil.php">
                    <img src="/image/jeunes.PNG" alt="Image">
                </a>
                
                
                <div class="texte">
                    <p> RÉFÉRENT </p>
                </div>
                <div class="t2">
                    <p> Je confirme la valeur de ton engagement</p>
                </div>
            </div>
            
        </div>
        
        <p class="dec">  Confirmez cette expérience et ce que vous avez <br>pu constater au contact de ce jeune. </p>

        <img src="/image/traitvert.jpg" alt="traitvert" class="traitvert">

        <div class="container">
            
            <div class="checkboxes">
                
                <form method="post" action="jeune.php" class="info">
                    <fieldset class="infos">
                        <label for="prenom"> Nom : </label>
                        <input type="text" id="nom" name="nom" maxlenght="50">
                            
                        <br><label for="prenom"> Prénom : </label>
                        <input type="text" id="prenom" name="prenom" maxlenght="50"/>
                        
                        <br>
                        <label for="date"> Date de naissance: </label>
                        <input type="date" id="date" name="date" placeholder="jj/mm/aaaa" pattern="\d{2}/\d{2}/\d{4}" required maxlenght="4">
                        <br>
                        <label for="email"> Email : </label>
                        <input type="email" id="email" name="email">
                            
                        <br>
                        <label for="reseau"> Réseau Social :  </label>
                        <input type="text" id="reseau" name="reseau">
                            
                        <br><br>
                        <label for="engagement"> Mon engagement: </label>
                        <input type="text" id="engagement" name="engagement">
                            
                        <br>
                        <label for="duree"> Durée : </label>
                        <input type="text" id="duree" name="duree">
                            
                        
                    </fieldset>
                </form>
        
        
        
                <form method="post">
                    <label><input type="checkbox" name="option1" value="option1" onclick="maxChoix()">Autonme</label>
                    <label><input type="checkbox" name="option2" value="option2" onclick="maxChoix()">Passioné</label>
                    <label><input type="checkbox" name="option3" value="option3" onclick="maxChoix()">Réfléchi</label>
                    <label><input type="checkbox" name="option4" value="option4" onclick="maxChoix()">A l'écoute</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Organisé</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Passioné</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Fiable</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Patient</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Réfléchi</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Responsable</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Social</label>
                    <label><input type="checkbox" name="option5" value="option5" onclick="maxChoix()">Optimiste</label>

                    <button type="submit" class="valider">Valider</button>
                </form>
            
            </div>
        </div>
        
        
        <div class="bandeVerte">
            <p class="ilEst"> Je confirme son/sa* </p>
        </div>
    
        <p class="maxChoix"> * Faire 4 choix maximum </p>
        
    </body>
</html>


