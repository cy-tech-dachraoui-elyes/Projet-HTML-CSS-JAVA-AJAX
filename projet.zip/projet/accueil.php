<!DOCTYPE html>

<? session_start();
    if (isset($_SESSION['user'])) {
       echo "Bienvenue" . htmlspecialchars($_SESSION['user']) . "!";
    } else {
        header("Location: connexion/connexion.php");
        exit;  
    }
    ?>

<html>
    
    <head>
        <meta charset="UTF-8">
        <title> Jeunes 6.4</title>
        <link rel="stylesheet" type="text/css" href="accueil.css">
    </head>
    
    <body>
        <div class="bande-grise">

            <div class="bande-centree">
                <div class="texte2">
                    
                    <a href="/Jeune/Jeune.php" class="aj">
                        <span> <button class="jeune"> JEUNE </button> </span>
                    </a>
                    
                    <a href="referent.php" class="ar">
                        <span class="referent">RÉFÉRENT</span>
                    </a>
                    
                    <a href="consultant.php" class="ac">
                        <span class="consultant">CONSULTANT</span>
                    </a>
                    
                    <a href="partenaire.html">
                        <span> <button class="partenaires"> PARTENAIRES </button> </span>
                    </a>
                    
                </div>
            </div>

            
                <div class="contenu">
                    <a href="accueil.php">
                        <img src="/image/jeunes.PNG" alt="Image">
                    </a>
                    
                    <div class="texte">
                            <div class="boutton">
                                    <a href="/inscription/Inscription.html" >
                                    <span> <button class="inscription"> Inscription </button> </span>
                                    </a>
                                    <a href="/connexion/connexion.php" >
                                            <span> <button class="connexion"> Connexion </button> </span>
                                    </a>
                                    </div>
                      <p>Pour faire de l'engagement une valeur</p>
                    </div>

                </div>
          
        </div>
        
            <p class="h1">De quoi s’agit-il? <br> </p>
            <p class="left">
                D’une opportunité : celle qu’un engagement quel qu’il soit puisse être <br>
                considéré à sa juste valeur ! <br>
                Toute expérience est source d’enrichissement et doit être reconnue <br>
                largement. <br>
                Elle révèle un potentiel, l’expression d’un savoir-être à concrétiser.
            </p>
            
        <div class="contenu">
            <p class="h2"> A qui s’adresse-t-il? <br> </p>
            <p class="p1">
                 A vous, jeunes entre 16 et 30 ans, qui vous êtes investis spontanément <br>
                 dans une association ou dans tout type d’action formelle ou informelle, et <br>
                 qui avez partagé de votre temps, de votre énergie, pour apporter un <br>
                 soutien, une aide, une compétence. <br>
                 <br>
             </p>
             
             <p class="p2">
                 A vous, responsables de structures ou référents d’un jour, qui avez <br>
                 croisé la route de ces jeunes et avez bénéficié même ponctuellement de <br>cette implication citoyenne ! <br>
                 C’est l’occasion de vous engager à votre tour pour ces jeunes en confir-<br>
                 mant leur richesse pour en avoir été un temps les témoins mais aussi les <br>
                 bénéficiaires !
            </p>
                
                <p class="r1">
                    A vous, employeurs, recruteurs en ressources humaines, représen-<br>
                    tants d’organismes de formation, qui recevez ces jeunes, pour un <br>
                    emploi, un stage, un cursus de qualification, pour qui le savoir-être consti-<br>
                    tue le premier fondement de toute capacité humaine.
                    <br>
                </p>
                <p class="r2">
                    <br>
                    Cet engagement est une ressource à valoriser au fil d'un <br>
                    parcours en 3 étapes :
                </p>
            </div>
            
            <a href="jeune.html">
                <img src="/image/rose.png" alt="jeune" class="rose">
            </a>
            <a href="referent.php">
                <img src="/image/vert.jpg" alt="jeune" class="vert">
            </a>
            
            <a href="consultant.php">
                <img src="/image/bleu.jpg" alt="jeune" class="bleu">
            </a>

        
    </body>
    
</html>


