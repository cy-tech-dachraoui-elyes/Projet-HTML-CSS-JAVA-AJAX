<?php

// Récupérer l'ID de la référence
$reference_id = $_POST['reference_id'];

// Lire le fichier JSON
$json = file_get_contents('../utilisateurs.json');

// Décoder le fichier JSON en tableau PHP
$data = json_decode($json, true);

// Trouver la référence archivée et la réactiver
foreach ($data['jeune'] as &$user) {
    if ($user['id'] === $id) { // Assurez-vous que $id contient l'ID correct de l'utilisateur
        foreach ($user['references'] as &$reference) {
            if ($reference['email_ref'] === $reference_id) {
                $reference['archived'] = false; // Assumant que vous utilisez 'archived' pour indiquer si une référence est archivée
                break 2; // Arrête les deux boucles
            }
        }
    }
}

// Encoder le tableau PHP en JSON
$json = json_encode($data, JSON_PRETTY_PRINT);

// Enregistrer le JSON
file_put_contents('../utilisateurs.json', $json);

// Rediriger l'utilisateur vers la page d'archives
header("Location: /archive.php");
exit;
?>
