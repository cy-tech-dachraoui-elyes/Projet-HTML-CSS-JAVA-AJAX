<?php
// Lire le fichier JSON
$json = file_get_contents('../utilisateurs.json');

// Décoder le fichier JSON en tableau PHP
$data = json_decode($json, true);

// Récupérer les références archivées de l'utilisateur
$archivedReferences = [];
foreach ($data['jeune'] as $user) {
    if ($user['id'] === $id) {
        foreach ($user['references'] as $reference) {
            if ($reference['archived']) {
                $archivedReferences[] = $reference;
            }
        }
        break;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Jeunes 6.4</title>
    <link rel="stylesheet" type="text/css" href="liste_reference.css">
    <script src="../fonction.js" type="text/javascript"> </script>
</head>

<body>
    <div class="bande-grise">
        <div class="contenu">
            <a href="../accueil.php">
                <img src="/image/jeunes.PNG" alt="Image">
            </a>
            <div class="texte">
                <p>JEUNE</p>
            </div>
            <div class="t2">
                <p>Archive</p>
            </div>
        </div>
        <div class="commande">
           
            <div class="profil">
                <a href="/profil/profil.php" class="button">Profil</a>
            </div>

            <div class="deconnexion">
                <a href="/deconnexion/deconnexion.php" class="button">Déconnexion</a>
            </div>
        </div>
    </div>

    <img src="/image/traitRose.jpg" alt="traitrose" class="traitrose">

    <div class="archived-references-container">
    <h2>Références archivées</h2>
    <!-- Boucle pour afficher les références archivées -->
    <?php foreach($archivedReferences as $reference): ?>
        <div class="reference reference-archived">
            <p><b>Référent:</b> <?php echo $reference['nom_ref']; echo " "; echo $reference['prenom_ref']; ?></p>
            <p><b>Engagement :</b> <?php echo $reference['engagement']; ?></p>
            <!-- Affichez d'autres détails de référence archivée selon vos besoins -->
            <form action="/reactivate.php" method="POST" style="display: inline;">
                <input type="hidden" name="reference_id" value="<?php echo $reference['email_ref']; ?>">
                <button type="submit" class="reactivate-reference"><b>Réactiver</b></button>
            </form>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>