<?php
session_start();

// Vérifier si l'utilisateur est connecté et s'il est un administrateur
if($_SESSION['role'] === 'admin') {
    // Récupérer les données des utilisateurs depuis le fichier JSON
    $users = json_decode(file_get_contents("../utilisateurs.json"), true);

    // Trouver l'utilisateur à supprimer et le supprimer
    foreach($users['jeune'] as $index => $user) {
        if($user['id'] === $_GET['id']){
            // Supprimer l'utilisateur
            unset($users['jeune'][$index]);
            // Enregistrer les modifications dans le fichier JSON
            file_put_contents("../utilisateurs.json", json_encode($users));
            break;
        }
    }
} else {
    // Si l'utilisateur n'est pas connecté ou s'il n'est pas un administrateur, le rediriger vers la page d'accueil
    header("Location: ../accueil.html");
    exit;
}
?>

<!-- Afficher un message de confirmation -->
<p>L'utilisateur a été supprimé.</p>