<?php
session_start();

// Vérifier si l'utilisateur est connecté et s'il est un administrateur
if($_SESSION['role'] === 'admin') {
    // Récupérer les données des utilisateurs depuis le fichier JSON
    $users = json_decode(file_get_contents("../utilisateurs.json"), true);

    // Si le formulaire a été soumis, mettre à jour l'utilisateur
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        foreach($users['jeune'] as &$user) {
            if($user['id'] === $_GET['id']){
                // Mettre à jour les informations de l'utilisateur
                $user['nom'] = $_POST['nom'];
                $user['prenom'] = $_POST['prenom'];
                $user['email'] = $_POST['email'];
                $user['date'] = $_POST['date'];
                $user['reseau'] = $_POST['reseau'];
                // Enregistrer les modifications dans le fichier JSON
                file_put_contents("../utilisateurs.json", json_encode($users));
                break;
            }
        }
    }

    // Trouver l'utilisateur à modifier
    foreach($users['jeune'] as $user) {
        if($user['id'] === $_GET['id']){
            $user_to_edit = $user;
            break;
        }
    }
} else {
    // Si l'utilisateur n'est pas connecté ou s'il n'est pas un administrateur, le rediriger vers la page d'accueil
    header("Location: ../accueil.html");
    exit;
}
?>

<!-- Afficher un formulaire pour modifier l'utilisateur -->
<form method="POST">
    Nom: <input type="text" name="nom" value="<?php echo $user_to_edit['nom']; ?>"><br>
    Prénom: <input type="text" name="prenom" value="<?php echo $user_to_edit['prenom']; ?>"><br>
    Email: <input type="text" name="email" value="<?php echo $user_to_edit['email']; ?>"><br>
    Date de naissance: <input type="date" name="date" value="<?php echo $user_to_edit['date']; ?>"><br>
    Réseau: <input type="text" name="reseau" value="<?php echo $user_to_edit['reseau']; ?>"><br>
    <input type="submit" value="Modifier">
</form>
